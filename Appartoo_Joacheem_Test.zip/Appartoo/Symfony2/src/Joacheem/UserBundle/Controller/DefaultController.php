<?php

namespace Joacheem\UserBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction($name)
    {
        return $this->render('JoacheemUserBundle:Default:index.html.twig', array('name' => $name));
    }
}
