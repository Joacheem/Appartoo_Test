<?php

namespace Joacheem\UserBundle\Controller;

use Symfony\Component\DependencyInjection\ContainerAware;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Joacheem\UserBundle\Entity\Contact;
use Joacheem\UserBundle\Form\ContactForm;
use Symfony\Component\HttpFoundation\Request;

class ContactController extends ContainerAware
{
    
    public function listerAction()
    {

        $em = $this->container->get('doctrine')->getEntityManager();

        $contacts= $em->getRepository('JoacheemUserBundle:Contact')->findAll();
	    
        return $this->container->get('templating')->renderResponse(
        'JoacheemUserBundle:Contact:lister.html.twig',
        array(
        'contacts' => $contacts,
    ));
    }
    
   

    public function editerAction()
    {
        $message ='';
        $em = $this->container->get('doctrine')->getEntityManager();

        if (isset($id)) 
        {
        // modification d'un acteur existant : on recherche ses données
        $acteur = $em->find('JoacheemUserBundle:Contact', $id);

        if (!$contact)
            {   
                $message='Aucun acteur trouvé';
            }
        }
        else 
        {
        // ajout d'un nouvel acteur
            $contact = new Contact();
        }

        $form = $this->container->get('form.factory')->create(new ContactForm(), $contact);

        $request = $this->container->get('request');

        if ($request->getMethod() == 'POST') 
        {
            $form->handleRequest($request);

            if ($form->isValid()) 
            {
                $em = $this->container->get('doctrine')->getEntityManager();
                $em->persist($contact);
                $em->flush();
                if (isset($id))
                {
                    $message='Contact modifié!';
                }
                else
                {
                    $message='Nouveau contact ajouté!';
                }
                
            }
        }

        return $this->container->get('templating')->renderResponse(
        'JoacheemUserBundle:Contact:editer.html.twig',
        array(
        'form' => $form->createView(),
        'message' => $message
    ));
    }

   


    public function supprimerAction($id)
    {
        $em = $this->container->get('doctrine')->getEntityManager();
        $contact = $em->find('JoacheemUserBundle:Contact', $id);

        if (!$contact) 
        {
            throw new NotFoundHttpException("Contact Introuvable");
        }
        
        $em->remove($contact);
        $em->flush();

        return new RedirectResponse($this->container->get('router')->generate('contact_lister'));
    }

}



