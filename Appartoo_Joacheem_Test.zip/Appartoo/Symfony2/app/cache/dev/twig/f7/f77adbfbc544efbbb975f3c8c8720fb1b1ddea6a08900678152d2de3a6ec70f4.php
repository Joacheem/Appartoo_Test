<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_c4bbe80cf06fb502facaf2ffe46f1d312dbd43caa8ea5730bf1e5b7a32551d65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5c660fae432c76169d77d9732d7b16e835f73ae0a68229feda66b1abd04c111c = $this->env->getExtension("native_profiler");
        $__internal_5c660fae432c76169d77d9732d7b16e835f73ae0a68229feda66b1abd04c111c->enter($__internal_5c660fae432c76169d77d9732d7b16e835f73ae0a68229feda66b1abd04c111c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_5c660fae432c76169d77d9732d7b16e835f73ae0a68229feda66b1abd04c111c->leave($__internal_5c660fae432c76169d77d9732d7b16e835f73ae0a68229feda66b1abd04c111c_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_30b517421df7c3a17826b12e33ec5f79f369a5cbef6ce5b6b3ecee65449f4dc8 = $this->env->getExtension("native_profiler");
        $__internal_30b517421df7c3a17826b12e33ec5f79f369a5cbef6ce5b6b3ecee65449f4dc8->enter($__internal_30b517421df7c3a17826b12e33ec5f79f369a5cbef6ce5b6b3ecee65449f4dc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_30b517421df7c3a17826b12e33ec5f79f369a5cbef6ce5b6b3ecee65449f4dc8->leave($__internal_30b517421df7c3a17826b12e33ec5f79f369a5cbef6ce5b6b3ecee65449f4dc8_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_5c3371f97bca85191c52e1aee49a5f2d6779e096dfcb513b4572d176081d235d = $this->env->getExtension("native_profiler");
        $__internal_5c3371f97bca85191c52e1aee49a5f2d6779e096dfcb513b4572d176081d235d->enter($__internal_5c3371f97bca85191c52e1aee49a5f2d6779e096dfcb513b4572d176081d235d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_5c3371f97bca85191c52e1aee49a5f2d6779e096dfcb513b4572d176081d235d->leave($__internal_5c3371f97bca85191c52e1aee49a5f2d6779e096dfcb513b4572d176081d235d_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_1ae3d8320cd5decfc2a7ccdcda41c96e880e9fbde9144e0c944d4bf2b75c5862 = $this->env->getExtension("native_profiler");
        $__internal_1ae3d8320cd5decfc2a7ccdcda41c96e880e9fbde9144e0c944d4bf2b75c5862->enter($__internal_1ae3d8320cd5decfc2a7ccdcda41c96e880e9fbde9144e0c944d4bf2b75c5862_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_1ae3d8320cd5decfc2a7ccdcda41c96e880e9fbde9144e0c944d4bf2b75c5862->leave($__internal_1ae3d8320cd5decfc2a7ccdcda41c96e880e9fbde9144e0c944d4bf2b75c5862_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
