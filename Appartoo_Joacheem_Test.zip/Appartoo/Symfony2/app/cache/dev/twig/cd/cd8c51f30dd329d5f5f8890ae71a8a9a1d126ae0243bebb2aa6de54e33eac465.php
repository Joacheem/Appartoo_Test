<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_d67bfa03a0f3eb3c27f3d924d92ea1467333f5f8b9e1c47f7e05f770eda55c10 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6f25b9526519c2cb17ed9279b8bca9700e7284e6664cf5baa824ee5c30c94338 = $this->env->getExtension("native_profiler");
        $__internal_6f25b9526519c2cb17ed9279b8bca9700e7284e6664cf5baa824ee5c30c94338->enter($__internal_6f25b9526519c2cb17ed9279b8bca9700e7284e6664cf5baa824ee5c30c94338_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_6f25b9526519c2cb17ed9279b8bca9700e7284e6664cf5baa824ee5c30c94338->leave($__internal_6f25b9526519c2cb17ed9279b8bca9700e7284e6664cf5baa824ee5c30c94338_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:error.xml.twig' %}*/
/* */
