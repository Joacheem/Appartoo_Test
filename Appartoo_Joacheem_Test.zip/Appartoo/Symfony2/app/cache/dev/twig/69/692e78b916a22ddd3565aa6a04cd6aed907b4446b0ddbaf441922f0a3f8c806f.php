<?php

/* JoacheemUserBundle:Default:index.html.twig */
class __TwigTemplate_4031cb4d6a27bbd1fd1106821884a07228d51986bd0442a5409cc5dcf67d931e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d99d48833815950004a848c7c504ccc191918346cbdebf9af20032801eb49ed7 = $this->env->getExtension("native_profiler");
        $__internal_d99d48833815950004a848c7c504ccc191918346cbdebf9af20032801eb49ed7->enter($__internal_d99d48833815950004a848c7c504ccc191918346cbdebf9af20032801eb49ed7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "JoacheemUserBundle:Default:index.html.twig"));

        // line 1
        echo "Hello ";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "!
";
        
        $__internal_d99d48833815950004a848c7c504ccc191918346cbdebf9af20032801eb49ed7->leave($__internal_d99d48833815950004a848c7c504ccc191918346cbdebf9af20032801eb49ed7_prof);

    }

    public function getTemplateName()
    {
        return "JoacheemUserBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello {{ name }}!*/
/* */
