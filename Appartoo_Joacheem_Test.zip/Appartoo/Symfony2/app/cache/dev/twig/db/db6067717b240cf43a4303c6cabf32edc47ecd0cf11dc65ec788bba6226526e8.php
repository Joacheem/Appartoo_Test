<?php

/* FOSUserBundle:Profile:show_content.html.twig */
class __TwigTemplate_8432189c00ad9ea21307c1223a8607fc302e3058c20d0308b2fa9c23c35bea4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f77c8bf6385a09777e347e6f2519dad01e608dae56f68f683296b6260c819c5e = $this->env->getExtension("native_profiler");
        $__internal_f77c8bf6385a09777e347e6f2519dad01e608dae56f68f683296b6260c819c5e->enter($__internal_f77c8bf6385a09777e347e6f2519dad01e608dae56f68f683296b6260c819c5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show_content.html.twig"));

        // line 2
        echo "
<div class=\"fos_user_user_show\">
\t<h1 >Bienvenue sur votre page d'acceuil ";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo " </h1></br> 
    <p>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("profile.show.username", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "html", null, true);
        echo "</p>
    <p>";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("profile.show.email", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "</p></br> 
    <p><a href=\"";
        // line 7
        echo $this->env->getExtension('routing')->getPath("contact_lister");
        echo "\">Vos contacts sur cette page</a></p>
    <p><a href=\"";
        // line 8
        echo $this->env->getExtension('routing')->getPath("fos_user_profile_edit");
        echo "\">Editer votre page</a></p>
</div>
";
        
        $__internal_f77c8bf6385a09777e347e6f2519dad01e608dae56f68f683296b6260c819c5e->leave($__internal_f77c8bf6385a09777e347e6f2519dad01e608dae56f68f683296b6260c819c5e_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 8,  42 => 7,  36 => 6,  30 => 5,  26 => 4,  22 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* <div class="fos_user_user_show">*/
/* 	<h1 >Bienvenue sur votre page d'acceuil {{ user.username }} </h1></br> */
/*     <p>{{ 'profile.show.username'|trans }}: {{ user.username }}</p>*/
/*     <p>{{ 'profile.show.email'|trans }}: {{ user.email }}</p></br> */
/*     <p><a href="{{ path('contact_lister') }}">Vos contacts sur cette page</a></p>*/
/*     <p><a href="{{ path('fos_user_profile_edit') }}">Editer votre page</a></p>*/
/* </div>*/
/* */
