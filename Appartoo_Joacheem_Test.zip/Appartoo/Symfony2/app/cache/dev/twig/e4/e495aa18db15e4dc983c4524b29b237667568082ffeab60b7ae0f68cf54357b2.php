<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_0754d1599d05c1cf0b39500e90b426d86235f281616bd990292dfc2d39a6608f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b90af869eab3380af7253b19e24a7d0eee146a215713ff4d83926670a54b21e2 = $this->env->getExtension("native_profiler");
        $__internal_b90af869eab3380af7253b19e24a7d0eee146a215713ff4d83926670a54b21e2->enter($__internal_b90af869eab3380af7253b19e24a7d0eee146a215713ff4d83926670a54b21e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b90af869eab3380af7253b19e24a7d0eee146a215713ff4d83926670a54b21e2->leave($__internal_b90af869eab3380af7253b19e24a7d0eee146a215713ff4d83926670a54b21e2_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_58490e2c8eb3e3657a0be4de141425844d490096d59cffa4000c5aac9109d891 = $this->env->getExtension("native_profiler");
        $__internal_58490e2c8eb3e3657a0be4de141425844d490096d59cffa4000c5aac9109d891->enter($__internal_58490e2c8eb3e3657a0be4de141425844d490096d59cffa4000c5aac9109d891_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_58490e2c8eb3e3657a0be4de141425844d490096d59cffa4000c5aac9109d891->leave($__internal_58490e2c8eb3e3657a0be4de141425844d490096d59cffa4000c5aac9109d891_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:request_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
