<?php

/* JoacheemUserBundle:Contact:afficher.html.twig */
class __TwigTemplate_6e81c01832709168c8e440dd6c3b86bef0c0f3a8d6d7b429e379170a4fc9e273 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84d74b8f5d0ca40cf76b1c4a6ef44c1f44ade1893ab8955afac0398779da48bb = $this->env->getExtension("native_profiler");
        $__internal_84d74b8f5d0ca40cf76b1c4a6ef44c1f44ade1893ab8955afac0398779da48bb->enter($__internal_84d74b8f5d0ca40cf76b1c4a6ef44c1f44ade1893ab8955afac0398779da48bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "JoacheemUserBundle:Contact:afficher.html.twig"));

        // line 1
        echo "<h1 style=\"color: aqua\">Liste des contacts</h1>

<div>
<table name =\"Mes contacts\" >
";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "contacts", array()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 6
            echo "\t<tr>
\t\t
\t\t<td>";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "prenom", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "nom", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "email", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "adresse", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "telephone", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "site", array()), "html", null, true);
            echo "</td>
\t\t<td><a href=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("contact_modifier", array("id" => $this->getAttribute($context["a"], "id", array()))), "html", null, true);
            echo "\">Modifier</a></td>
\t\t<td><a href=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("contact_supprimer", array("id" => $this->getAttribute($context["a"], "id", array()))), "html", null, true);
            echo "\">Supprimer</a></td>
\t</tr>
";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 18
            echo "\t<tr><td>Vous n'avez pas de contact.</td></tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "</table>
</div>
<p><a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("contact_lister");
        echo "\">Afficher mes contact</a><p>
<p><a href=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("contact_ajouter");
        echo "\">Ajouter un contact</a><p>";
        
        $__internal_84d74b8f5d0ca40cf76b1c4a6ef44c1f44ade1893ab8955afac0398779da48bb->leave($__internal_84d74b8f5d0ca40cf76b1c4a6ef44c1f44ade1893ab8955afac0398779da48bb_prof);

    }

    public function getTemplateName()
    {
        return "JoacheemUserBundle:Contact:afficher.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 23,  84 => 22,  80 => 20,  73 => 18,  65 => 15,  61 => 14,  57 => 13,  53 => 12,  49 => 11,  45 => 10,  41 => 9,  37 => 8,  33 => 6,  28 => 5,  22 => 1,);
    }
}
/* <h1 style="color: aqua">Liste des contacts</h1>*/
/* */
/* <div>*/
/* <table name ="Mes contacts" >*/
/* {% for a in user.contacts %}*/
/* 	<tr>*/
/* 		*/
/* 		<td>{{ a.prenom }}</td>*/
/* 		<td>{{ a.nom }}</td>*/
/* 		<td>{{ a.email }}</td>*/
/* 		<td>{{ a.adresse }}</td>*/
/* 		<td>{{ a.telephone }}</td>*/
/* 		<td>{{ a.site }}</td>*/
/* 		<td><a href="{{ path('contact_modifier', { 'id': a.id }) }}">Modifier</a></td>*/
/* 		<td><a href="{{ path('contact_supprimer', { 'id': a.id }) }}">Supprimer</a></td>*/
/* 	</tr>*/
/* {% else %}*/
/* 	<tr><td>Vous n'avez pas de contact.</td></tr>*/
/* {% endfor %}*/
/* </table>*/
/* </div>*/
/* <p><a href="{{ path('contact_lister') }}">Afficher mes contact</a><p>*/
/* <p><a href="{{ path('contact_ajouter') }}">Ajouter un contact</a><p>*/
