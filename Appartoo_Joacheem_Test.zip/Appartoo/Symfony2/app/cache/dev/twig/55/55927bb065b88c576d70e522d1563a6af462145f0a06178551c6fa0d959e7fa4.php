<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_0db21a54a4494a7720ed64fcd06d6eb636eb928be93e8ead7688306e2991a7e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed61eaf285c09c0d94df13007692e695c5ee73435cece4d4c4c64f5de5011bfa = $this->env->getExtension("native_profiler");
        $__internal_ed61eaf285c09c0d94df13007692e695c5ee73435cece4d4c4c64f5de5011bfa->enter($__internal_ed61eaf285c09c0d94df13007692e695c5ee73435cece4d4c4c64f5de5011bfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ed61eaf285c09c0d94df13007692e695c5ee73435cece4d4c4c64f5de5011bfa->leave($__internal_ed61eaf285c09c0d94df13007692e695c5ee73435cece4d4c4c64f5de5011bfa_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b14c2299651ec42df9c4bd1621d2cc4725bec00cd08c2905faa3721a12a25344 = $this->env->getExtension("native_profiler");
        $__internal_b14c2299651ec42df9c4bd1621d2cc4725bec00cd08c2905faa3721a12a25344->enter($__internal_b14c2299651ec42df9c4bd1621d2cc4725bec00cd08c2905faa3721a12a25344_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_b14c2299651ec42df9c4bd1621d2cc4725bec00cd08c2905faa3721a12a25344->leave($__internal_b14c2299651ec42df9c4bd1621d2cc4725bec00cd08c2905faa3721a12a25344_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:new_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
