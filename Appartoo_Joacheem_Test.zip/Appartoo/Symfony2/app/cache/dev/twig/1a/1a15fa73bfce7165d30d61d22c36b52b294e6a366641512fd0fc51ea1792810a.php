<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_6ec05f2004020251f537a4fcd8955bfcf50e48de0798c7f9994def82e5e7c7aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_18ecf9d595ba855c45d1a3fba505ffc81231bd34e4d564a53d737fe2b0665062 = $this->env->getExtension("native_profiler");
        $__internal_18ecf9d595ba855c45d1a3fba505ffc81231bd34e4d564a53d737fe2b0665062->enter($__internal_18ecf9d595ba855c45d1a3fba505ffc81231bd34e4d564a53d737fe2b0665062_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_18ecf9d595ba855c45d1a3fba505ffc81231bd34e4d564a53d737fe2b0665062->leave($__internal_18ecf9d595ba855c45d1a3fba505ffc81231bd34e4d564a53d737fe2b0665062_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_daf6d0a73bd8391e2381bc9cc07045f242256ce7a4e9426df1c729665e0814e8 = $this->env->getExtension("native_profiler");
        $__internal_daf6d0a73bd8391e2381bc9cc07045f242256ce7a4e9426df1c729665e0814e8->enter($__internal_daf6d0a73bd8391e2381bc9cc07045f242256ce7a4e9426df1c729665e0814e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_daf6d0a73bd8391e2381bc9cc07045f242256ce7a4e9426df1c729665e0814e8->leave($__internal_daf6d0a73bd8391e2381bc9cc07045f242256ce7a4e9426df1c729665e0814e8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
