<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_ed5a7aa1fe0d747ced8571884ff46130e5d6507866684a49d3bf0b7dbbf28988 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_23a7b5613e57feba875a9a4305be0f006514edc28b2ae4e629f77c2da8bb4844 = $this->env->getExtension("native_profiler");
        $__internal_23a7b5613e57feba875a9a4305be0f006514edc28b2ae4e629f77c2da8bb4844->enter($__internal_23a7b5613e57feba875a9a4305be0f006514edc28b2ae4e629f77c2da8bb4844_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_23a7b5613e57feba875a9a4305be0f006514edc28b2ae4e629f77c2da8bb4844->leave($__internal_23a7b5613e57feba875a9a4305be0f006514edc28b2ae4e629f77c2da8bb4844_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_78ead0a8f7832f99d17db1a0a5ba4e1aa5ce7a83a0d1e9b5638c7d579f2d721f = $this->env->getExtension("native_profiler");
        $__internal_78ead0a8f7832f99d17db1a0a5ba4e1aa5ce7a83a0d1e9b5638c7d579f2d721f->enter($__internal_78ead0a8f7832f99d17db1a0a5ba4e1aa5ce7a83a0d1e9b5638c7d579f2d721f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_78ead0a8f7832f99d17db1a0a5ba4e1aa5ce7a83a0d1e9b5638c7d579f2d721f->leave($__internal_78ead0a8f7832f99d17db1a0a5ba4e1aa5ce7a83a0d1e9b5638c7d579f2d721f_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
