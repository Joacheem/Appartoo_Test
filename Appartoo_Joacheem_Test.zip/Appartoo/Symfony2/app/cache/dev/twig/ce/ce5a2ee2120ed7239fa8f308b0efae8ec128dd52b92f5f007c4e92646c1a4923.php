<?php

/* FOSUserBundle:Registration:checkEmail.html.twig */
class __TwigTemplate_ddb0d672ac3b4ba94cd3411468ac725ddd477f18890cfc7090b00ded202c526e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_76f2dca7b0511c0d89632c0faf51119609ab5b5f3db6f286d34b4c205978bde7 = $this->env->getExtension("native_profiler");
        $__internal_76f2dca7b0511c0d89632c0faf51119609ab5b5f3db6f286d34b4c205978bde7->enter($__internal_76f2dca7b0511c0d89632c0faf51119609ab5b5f3db6f286d34b4c205978bde7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_76f2dca7b0511c0d89632c0faf51119609ab5b5f3db6f286d34b4c205978bde7->leave($__internal_76f2dca7b0511c0d89632c0faf51119609ab5b5f3db6f286d34b4c205978bde7_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_71b5d8b2da5c70134582982d9371fc45ac4acac9a6ce5c27c39eb96d6aec31e0 = $this->env->getExtension("native_profiler");
        $__internal_71b5d8b2da5c70134582982d9371fc45ac4acac9a6ce5c27c39eb96d6aec31e0->enter($__internal_71b5d8b2da5c70134582982d9371fc45ac4acac9a6ce5c27c39eb96d6aec31e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_71b5d8b2da5c70134582982d9371fc45ac4acac9a6ce5c27c39eb96d6aec31e0->leave($__internal_71b5d8b2da5c70134582982d9371fc45ac4acac9a6ce5c27c39eb96d6aec31e0_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/*     <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
