<?php

/* FOSUserBundle:ChangePassword:changePassword.html.twig */
class __TwigTemplate_5e0bd8f2248698d412fc6eeffd9e442e9f768ed99772aa8bd1b3183740f0e695 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_db233127d27c66998413eff5184ce6b301569cf3d6c1eddb4ceacaf36178b19f = $this->env->getExtension("native_profiler");
        $__internal_db233127d27c66998413eff5184ce6b301569cf3d6c1eddb4ceacaf36178b19f->enter($__internal_db233127d27c66998413eff5184ce6b301569cf3d6c1eddb4ceacaf36178b19f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:changePassword.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_db233127d27c66998413eff5184ce6b301569cf3d6c1eddb4ceacaf36178b19f->leave($__internal_db233127d27c66998413eff5184ce6b301569cf3d6c1eddb4ceacaf36178b19f_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_28567cfbc0f5022e94374e510d32f3de5882e5c6abfc8e2206f4dcf8f7f75c91 = $this->env->getExtension("native_profiler");
        $__internal_28567cfbc0f5022e94374e510d32f3de5882e5c6abfc8e2206f4dcf8f7f75c91->enter($__internal_28567cfbc0f5022e94374e510d32f3de5882e5c6abfc8e2206f4dcf8f7f75c91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:ChangePassword:changePassword_content.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 4)->display($context);
        
        $__internal_28567cfbc0f5022e94374e510d32f3de5882e5c6abfc8e2206f4dcf8f7f75c91->leave($__internal_28567cfbc0f5022e94374e510d32f3de5882e5c6abfc8e2206f4dcf8f7f75c91_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:changePassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:ChangePassword:changePassword_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
