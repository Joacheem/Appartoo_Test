<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_0d339974ecbff63177acc6e19bf9e76c1f269215e3b4fdf1d564f7592e9d6c66 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ded2258f58fd91cfaddde8af9ad62b4ae39aa1af5daec4737d9b455b928c76a6 = $this->env->getExtension("native_profiler");
        $__internal_ded2258f58fd91cfaddde8af9ad62b4ae39aa1af5daec4737d9b455b928c76a6->enter($__internal_ded2258f58fd91cfaddde8af9ad62b4ae39aa1af5daec4737d9b455b928c76a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("TwigBundle:Exception:exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_ded2258f58fd91cfaddde8af9ad62b4ae39aa1af5daec4737d9b455b928c76a6->leave($__internal_ded2258f58fd91cfaddde8af9ad62b4ae39aa1af5daec4737d9b455b928c76a6_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include 'TwigBundle:Exception:exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
