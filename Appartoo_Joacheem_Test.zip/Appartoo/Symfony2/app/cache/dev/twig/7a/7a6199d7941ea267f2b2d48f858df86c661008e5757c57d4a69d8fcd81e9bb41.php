<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_2be064c96fabdfce674656747d90b8cf2a4500467ac58ab01b10c3f66da6748e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df134433eba268fb9b77f3d5963c52a27d4736b979d3f9bd841721a94f7467f2 = $this->env->getExtension("native_profiler");
        $__internal_df134433eba268fb9b77f3d5963c52a27d4736b979d3f9bd841721a94f7467f2->enter($__internal_df134433eba268fb9b77f3d5963c52a27d4736b979d3f9bd841721a94f7467f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_df134433eba268fb9b77f3d5963c52a27d4736b979d3f9bd841721a94f7467f2->leave($__internal_df134433eba268fb9b77f3d5963c52a27d4736b979d3f9bd841721a94f7467f2_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_0fd79b298729829022a63b3dda6e64615c31db53874f5662d24f38d730cbba20 = $this->env->getExtension("native_profiler");
        $__internal_0fd79b298729829022a63b3dda6e64615c31db53874f5662d24f38d730cbba20->enter($__internal_0fd79b298729829022a63b3dda6e64615c31db53874f5662d24f38d730cbba20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_0fd79b298729829022a63b3dda6e64615c31db53874f5662d24f38d730cbba20->leave($__internal_0fd79b298729829022a63b3dda6e64615c31db53874f5662d24f38d730cbba20_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
