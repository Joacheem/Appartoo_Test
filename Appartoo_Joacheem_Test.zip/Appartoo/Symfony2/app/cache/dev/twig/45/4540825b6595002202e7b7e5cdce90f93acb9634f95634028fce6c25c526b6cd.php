<?php

/* ::base.html.twig */
class __TwigTemplate_35272c624ac8908114621ca55e262ac6cc7eb9e461786e2e034dfab296f7c837 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d6f915ae51b6fcf31708df1aaea359e2963da8a03940816462694bb5a5a9eab1 = $this->env->getExtension("native_profiler");
        $__internal_d6f915ae51b6fcf31708df1aaea359e2963da8a03940816462694bb5a5a9eab1->enter($__internal_d6f915ae51b6fcf31708df1aaea359e2963da8a03940816462694bb5a5a9eab1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_d6f915ae51b6fcf31708df1aaea359e2963da8a03940816462694bb5a5a9eab1->leave($__internal_d6f915ae51b6fcf31708df1aaea359e2963da8a03940816462694bb5a5a9eab1_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_566da87f3203395a00b12cae89be9da13e8a1b4a6275da477227fce5af52096d = $this->env->getExtension("native_profiler");
        $__internal_566da87f3203395a00b12cae89be9da13e8a1b4a6275da477227fce5af52096d->enter($__internal_566da87f3203395a00b12cae89be9da13e8a1b4a6275da477227fce5af52096d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_566da87f3203395a00b12cae89be9da13e8a1b4a6275da477227fce5af52096d->leave($__internal_566da87f3203395a00b12cae89be9da13e8a1b4a6275da477227fce5af52096d_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_bc4dcf5eb6595b184f090d70a5a51a7dacb0a9732bb0f079b98348f3c1dc8f4c = $this->env->getExtension("native_profiler");
        $__internal_bc4dcf5eb6595b184f090d70a5a51a7dacb0a9732bb0f079b98348f3c1dc8f4c->enter($__internal_bc4dcf5eb6595b184f090d70a5a51a7dacb0a9732bb0f079b98348f3c1dc8f4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_bc4dcf5eb6595b184f090d70a5a51a7dacb0a9732bb0f079b98348f3c1dc8f4c->leave($__internal_bc4dcf5eb6595b184f090d70a5a51a7dacb0a9732bb0f079b98348f3c1dc8f4c_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_0ab95273583e157983ddddda3dc0e8f4b95e3f0c5dcbf800f052b90f7c212961 = $this->env->getExtension("native_profiler");
        $__internal_0ab95273583e157983ddddda3dc0e8f4b95e3f0c5dcbf800f052b90f7c212961->enter($__internal_0ab95273583e157983ddddda3dc0e8f4b95e3f0c5dcbf800f052b90f7c212961_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_0ab95273583e157983ddddda3dc0e8f4b95e3f0c5dcbf800f052b90f7c212961->leave($__internal_0ab95273583e157983ddddda3dc0e8f4b95e3f0c5dcbf800f052b90f7c212961_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_f2a773bad3e64ec049a456e4dcaa46b4945b85d9f185c462fba65660727224d2 = $this->env->getExtension("native_profiler");
        $__internal_f2a773bad3e64ec049a456e4dcaa46b4945b85d9f185c462fba65660727224d2->enter($__internal_f2a773bad3e64ec049a456e4dcaa46b4945b85d9f185c462fba65660727224d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_f2a773bad3e64ec049a456e4dcaa46b4945b85d9f185c462fba65660727224d2->leave($__internal_f2a773bad3e64ec049a456e4dcaa46b4945b85d9f185c462fba65660727224d2_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
