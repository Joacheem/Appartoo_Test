<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_51d94fe7b522b48167c5186d38a72fecda48c3244c0743f4e27f8c5ab1c39cb4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0090328d9cbcdacd5aded1d84d164690404c29ab1cfb714e5fd0e6f695414abf = $this->env->getExtension("native_profiler");
        $__internal_0090328d9cbcdacd5aded1d84d164690404c29ab1cfb714e5fd0e6f695414abf->enter($__internal_0090328d9cbcdacd5aded1d84d164690404c29ab1cfb714e5fd0e6f695414abf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("TwigBundle:Exception:exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_0090328d9cbcdacd5aded1d84d164690404c29ab1cfb714e5fd0e6f695414abf->leave($__internal_0090328d9cbcdacd5aded1d84d164690404c29ab1cfb714e5fd0e6f695414abf_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include 'TwigBundle:Exception:exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
