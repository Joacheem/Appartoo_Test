<?php

/* JoacheemUserBundle:Contact:editer.html.twig */
class __TwigTemplate_3dbcd601a44b98685793cd6f0c1ec518c28bb3266132e676b06b72e35e2d6187 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2e54f7409f2632053b265b0cd93677021f9d0641145f99be8541b886dbcfab8f = $this->env->getExtension("native_profiler");
        $__internal_2e54f7409f2632053b265b0cd93677021f9d0641145f99be8541b886dbcfab8f->enter($__internal_2e54f7409f2632053b265b0cd93677021f9d0641145f99be8541b886dbcfab8f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "JoacheemUserBundle:Contact:editer.html.twig"));

        // line 1
        echo "<h1>Ajouter un contact</h1>

";
        // line 3
        if ((isset($context["message"]) ? $context["message"] : $this->getContext($context, "message"))) {
            // line 4
            echo "<p>";
            echo twig_escape_filter($this->env, (isset($context["message"]) ? $context["message"] : $this->getContext($context, "message")), "html", null, true);
            echo "</p>
";
        }
        // line 6
        echo "
<form action=\"\" method=\"post\" ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'enctype');
        echo ">
    ";
        // line 8
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    <input type=\"submit\" />
</form>
<p><a href=\"";
        // line 11
        echo $this->env->getExtension('routing')->getPath("contact_lister");
        echo "\">Retour à la liste des contacts</a></p>
<p><a href=\"";
        // line 12
        echo $this->env->getExtension('routing')->getPath("fos_user_profile_show");
        echo "\">Retour à la page d'acceuil</a><p>";
        
        $__internal_2e54f7409f2632053b265b0cd93677021f9d0641145f99be8541b886dbcfab8f->leave($__internal_2e54f7409f2632053b265b0cd93677021f9d0641145f99be8541b886dbcfab8f_prof);

    }

    public function getTemplateName()
    {
        return "JoacheemUserBundle:Contact:editer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 12,  47 => 11,  41 => 8,  37 => 7,  34 => 6,  28 => 4,  26 => 3,  22 => 1,);
    }
}
/* <h1>Ajouter un contact</h1>*/
/* */
/* {% if message %}*/
/* <p>{{ message }}</p>*/
/* {% endif %}*/
/* */
/* <form action="" method="post" {{ form_enctype(form) }}>*/
/*     {{ form_widget(form) }}*/
/*     <input type="submit" />*/
/* </form>*/
/* <p><a href="{{ path('contact_lister') }}">Retour à la liste des contacts</a></p>*/
/* <p><a href="{{ path('fos_user_profile_show') }}">Retour à la page d'acceuil</a><p>*/
