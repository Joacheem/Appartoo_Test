<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_4a425a22412e539df2b5b35dea117c445983ae66a6b19e1bfba9510dce95feb6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_35ee68c6b4b6d1f0a6e39a04326dad827864b3929608dd025a764c6cc46f0192 = $this->env->getExtension("native_profiler");
        $__internal_35ee68c6b4b6d1f0a6e39a04326dad827864b3929608dd025a764c6cc46f0192->enter($__internal_35ee68c6b4b6d1f0a6e39a04326dad827864b3929608dd025a764c6cc46f0192_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_35ee68c6b4b6d1f0a6e39a04326dad827864b3929608dd025a764c6cc46f0192->leave($__internal_35ee68c6b4b6d1f0a6e39a04326dad827864b3929608dd025a764c6cc46f0192_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:exception.xml.twig' with { 'exception': exception } %}*/
/* */
