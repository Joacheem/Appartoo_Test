<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_8dfaf566a214a486f5ed6b9d75a8c18a4af6709081c5f36c608dbc4336b3f4f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2dc37e27bf44f2ec1ab8d81f1631f868bc698b90f07872e9022a6c565d565ac0 = $this->env->getExtension("native_profiler");
        $__internal_2dc37e27bf44f2ec1ab8d81f1631f868bc698b90f07872e9022a6c565d565ac0->enter($__internal_2dc37e27bf44f2ec1ab8d81f1631f868bc698b90f07872e9022a6c565d565ac0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_2dc37e27bf44f2ec1ab8d81f1631f868bc698b90f07872e9022a6c565d565ac0->leave($__internal_2dc37e27bf44f2ec1ab8d81f1631f868bc698b90f07872e9022a6c565d565ac0_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:error.xml.twig' %}*/
/* */
