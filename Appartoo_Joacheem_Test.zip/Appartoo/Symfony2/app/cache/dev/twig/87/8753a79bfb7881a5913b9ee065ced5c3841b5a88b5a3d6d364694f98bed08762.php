<?php

/* JoacheemUserBundle:Contact:lister.html.twig */
class __TwigTemplate_3d009699b9ec7396a719cc76bde70f248d1075c94b2f53200ff87d9b7141b81c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ffcba58c0f3d432bbe8feb0cf415c9d612412d6e9da98ad4b8eb279cafe93969 = $this->env->getExtension("native_profiler");
        $__internal_ffcba58c0f3d432bbe8feb0cf415c9d612412d6e9da98ad4b8eb279cafe93969->enter($__internal_ffcba58c0f3d432bbe8feb0cf415c9d612412d6e9da98ad4b8eb279cafe93969_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "JoacheemUserBundle:Contact:lister.html.twig"));

        // line 1
        echo "
<h1>Liste des contacts</h1>

<div>
<table>
";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["contacts"]) ? $context["contacts"] : $this->getContext($context, "contacts")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 7
            echo "\t<tr>
\t\t
\t\t<td>";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "prenom", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "nom", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "email", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "adresse", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "telephone", array()), "html", null, true);
            echo "</td>
\t\t<td>";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["a"], "site", array()), "html", null, true);
            echo "</td>
\t\t<td><a href=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("contact_modifier", array("id" => $this->getAttribute($context["a"], "id", array()))), "html", null, true);
            echo "\">Modifier</a></td>
\t\t<td><a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("contact_supprimer", array("id" => $this->getAttribute($context["a"], "id", array()))), "html", null, true);
            echo "\">Supprimer</a></td>
\t</tr>
";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 19
            echo "\t<tr><td>Aucun contact n'a été trouvé.</td></tr>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "</table>
</div>
<p><a href=\"";
        // line 23
        echo $this->env->getExtension('routing')->getPath("contact_ajouter");
        echo "\">Ajouter un contact</a><p>
<p><a href=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("fos_user_profile_show");
        echo "\">Retour à la page d'acceuil</a><p>

";
        
        $__internal_ffcba58c0f3d432bbe8feb0cf415c9d612412d6e9da98ad4b8eb279cafe93969->leave($__internal_ffcba58c0f3d432bbe8feb0cf415c9d612412d6e9da98ad4b8eb279cafe93969_prof);

    }

    public function getTemplateName()
    {
        return "JoacheemUserBundle:Contact:lister.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 24,  85 => 23,  81 => 21,  74 => 19,  66 => 16,  62 => 15,  58 => 14,  54 => 13,  50 => 12,  46 => 11,  42 => 10,  38 => 9,  34 => 7,  29 => 6,  22 => 1,);
    }
}
/* */
/* <h1>Liste des contacts</h1>*/
/* */
/* <div>*/
/* <table>*/
/* {% for a in contacts %}*/
/* 	<tr>*/
/* 		*/
/* 		<td>{{ a.prenom }}</td>*/
/* 		<td>{{ a.nom }}</td>*/
/* 		<td>{{ a.email }}</td>*/
/* 		<td>{{ a.adresse }}</td>*/
/* 		<td>{{ a.telephone }}</td>*/
/* 		<td>{{ a.site }}</td>*/
/* 		<td><a href="{{ path('contact_modifier', { 'id': a.id }) }}">Modifier</a></td>*/
/* 		<td><a href="{{ path('contact_supprimer', { 'id': a.id }) }}">Supprimer</a></td>*/
/* 	</tr>*/
/* {% else %}*/
/* 	<tr><td>Aucun contact n'a été trouvé.</td></tr>*/
/* {% endfor %}*/
/* </table>*/
/* </div>*/
/* <p><a href="{{ path('contact_ajouter') }}">Ajouter un contact</a><p>*/
/* <p><a href="{{ path('fos_user_profile_show') }}">Retour à la page d'acceuil</a><p>*/
/* */
/* */
