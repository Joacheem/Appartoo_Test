<?php

/* FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig */
class __TwigTemplate_8806aae1bae7b570c86f09fa96fd5d5449941e3eec6c16706a3bbff911f2d38a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e765083d44fdd3502679ec4383827b9e04bdf5cb1ac983cce2311738aeafc2e4 = $this->env->getExtension("native_profiler");
        $__internal_e765083d44fdd3502679ec4383827b9e04bdf5cb1ac983cce2311738aeafc2e4->enter($__internal_e765083d44fdd3502679ec4383827b9e04bdf5cb1ac983cce2311738aeafc2e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e765083d44fdd3502679ec4383827b9e04bdf5cb1ac983cce2311738aeafc2e4->leave($__internal_e765083d44fdd3502679ec4383827b9e04bdf5cb1ac983cce2311738aeafc2e4_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_28582028e0667783d49d430114658e1193ee25f5c1a4e41d258bee5a11fd109b = $this->env->getExtension("native_profiler");
        $__internal_28582028e0667783d49d430114658e1193ee25f5c1a4e41d258bee5a11fd109b->enter($__internal_28582028e0667783d49d430114658e1193ee25f5c1a4e41d258bee5a11fd109b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_28582028e0667783d49d430114658e1193ee25f5c1a4e41d258bee5a11fd109b->leave($__internal_28582028e0667783d49d430114658e1193ee25f5c1a4e41d258bee5a11fd109b_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>{{ 'resetting.password_already_requested'|trans }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
