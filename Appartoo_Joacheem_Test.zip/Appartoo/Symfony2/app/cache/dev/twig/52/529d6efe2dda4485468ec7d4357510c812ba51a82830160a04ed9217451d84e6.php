<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_d4c922d1c1c33a0f474fab177dcdf2477f7beaf333fd918c40ce0aa84020dd5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b09cd48e303e852cdf62a38b396809ea1dae3f86da9833f6c4e103ac9e44902 = $this->env->getExtension("native_profiler");
        $__internal_9b09cd48e303e852cdf62a38b396809ea1dae3f86da9833f6c4e103ac9e44902->enter($__internal_9b09cd48e303e852cdf62a38b396809ea1dae3f86da9833f6c4e103ac9e44902_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_9b09cd48e303e852cdf62a38b396809ea1dae3f86da9833f6c4e103ac9e44902->leave($__internal_9b09cd48e303e852cdf62a38b396809ea1dae3f86da9833f6c4e103ac9e44902_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_baa1d61c6105b8fc27714be85295708b6c591e9209d9231f9ce382061dc84be7 = $this->env->getExtension("native_profiler");
        $__internal_baa1d61c6105b8fc27714be85295708b6c591e9209d9231f9ce382061dc84be7->enter($__internal_baa1d61c6105b8fc27714be85295708b6c591e9209d9231f9ce382061dc84be7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_baa1d61c6105b8fc27714be85295708b6c591e9209d9231f9ce382061dc84be7->leave($__internal_baa1d61c6105b8fc27714be85295708b6c591e9209d9231f9ce382061dc84be7_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
