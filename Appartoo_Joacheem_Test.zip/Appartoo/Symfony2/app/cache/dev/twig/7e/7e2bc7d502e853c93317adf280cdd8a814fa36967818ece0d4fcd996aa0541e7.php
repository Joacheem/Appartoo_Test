<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_9c7be1a135c08a7bccbea56cba3f48bf30151ee219b64f4cb8f3d38e93fdaef6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a28996fb17faae9b37806520fc1760566f9a64c6dedaaefb8e6ddb70310f75e = $this->env->getExtension("native_profiler");
        $__internal_1a28996fb17faae9b37806520fc1760566f9a64c6dedaaefb8e6ddb70310f75e->enter($__internal_1a28996fb17faae9b37806520fc1760566f9a64c6dedaaefb8e6ddb70310f75e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1a28996fb17faae9b37806520fc1760566f9a64c6dedaaefb8e6ddb70310f75e->leave($__internal_1a28996fb17faae9b37806520fc1760566f9a64c6dedaaefb8e6ddb70310f75e_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f567356a56f5e48f46ffa83a19345b24e33935587b716bb33151a8c262d34281 = $this->env->getExtension("native_profiler");
        $__internal_f567356a56f5e48f46ffa83a19345b24e33935587b716bb33151a8c262d34281->enter($__internal_f567356a56f5e48f46ffa83a19345b24e33935587b716bb33151a8c262d34281_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_f567356a56f5e48f46ffa83a19345b24e33935587b716bb33151a8c262d34281->leave($__internal_f567356a56f5e48f46ffa83a19345b24e33935587b716bb33151a8c262d34281_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:reset_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
