<?php

/* SensioDistributionBundle::Configurator/layout.html.twig */
class __TwigTemplate_300f2c863b5d930765a82ba4832f835e85e424ba93a682970e26d872fe319be9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "SensioDistributionBundle::Configurator/layout.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d2bdd8f22815ce0138ff7718f1629fe01b35e5a855b8ddae88a30318d48b6b04 = $this->env->getExtension("native_profiler");
        $__internal_d2bdd8f22815ce0138ff7718f1629fe01b35e5a855b8ddae88a30318d48b6b04->enter($__internal_d2bdd8f22815ce0138ff7718f1629fe01b35e5a855b8ddae88a30318d48b6b04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SensioDistributionBundle::Configurator/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d2bdd8f22815ce0138ff7718f1629fe01b35e5a855b8ddae88a30318d48b6b04->leave($__internal_d2bdd8f22815ce0138ff7718f1629fe01b35e5a855b8ddae88a30318d48b6b04_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_440d48662a32c6af786bbdba929a8f4c9b355a32b411d838a17704e47100a28e = $this->env->getExtension("native_profiler");
        $__internal_440d48662a32c6af786bbdba929a8f4c9b355a32b411d838a17704e47100a28e->enter($__internal_440d48662a32c6af786bbdba929a8f4c9b355a32b411d838a17704e47100a28e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/sensiodistribution/webconfigurator/css/configurator.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_440d48662a32c6af786bbdba929a8f4c9b355a32b411d838a17704e47100a28e->leave($__internal_440d48662a32c6af786bbdba929a8f4c9b355a32b411d838a17704e47100a28e_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_e7db825b79bd312b73b8ef13d85cab559eac896d0a4680784c5fdf77a2bb9f70 = $this->env->getExtension("native_profiler");
        $__internal_e7db825b79bd312b73b8ef13d85cab559eac896d0a4680784c5fdf77a2bb9f70->enter($__internal_e7db825b79bd312b73b8ef13d85cab559eac896d0a4680784c5fdf77a2bb9f70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Web Configurator Bundle";
        
        $__internal_e7db825b79bd312b73b8ef13d85cab559eac896d0a4680784c5fdf77a2bb9f70->leave($__internal_e7db825b79bd312b73b8ef13d85cab559eac896d0a4680784c5fdf77a2bb9f70_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_ccce30dbb03aab84294b092c33e087820da099bfe0dce5d6b21dbad0625441d5 = $this->env->getExtension("native_profiler");
        $__internal_ccce30dbb03aab84294b092c33e087820da099bfe0dce5d6b21dbad0625441d5->enter($__internal_ccce30dbb03aab84294b092c33e087820da099bfe0dce5d6b21dbad0625441d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <div class=\"block\">
        ";
        // line 11
        $this->displayBlock('content', $context, $blocks);
        // line 12
        echo "    </div>
    <div class=\"version\">Symfony Standard Edition v.";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "</div>
";
        
        $__internal_ccce30dbb03aab84294b092c33e087820da099bfe0dce5d6b21dbad0625441d5->leave($__internal_ccce30dbb03aab84294b092c33e087820da099bfe0dce5d6b21dbad0625441d5_prof);

    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        $__internal_01a886f47a85e878ac507c8f5d6be37a6a1e0c58ea3f30464bff57dfc8b2b4b6 = $this->env->getExtension("native_profiler");
        $__internal_01a886f47a85e878ac507c8f5d6be37a6a1e0c58ea3f30464bff57dfc8b2b4b6->enter($__internal_01a886f47a85e878ac507c8f5d6be37a6a1e0c58ea3f30464bff57dfc8b2b4b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_01a886f47a85e878ac507c8f5d6be37a6a1e0c58ea3f30464bff57dfc8b2b4b6->leave($__internal_01a886f47a85e878ac507c8f5d6be37a6a1e0c58ea3f30464bff57dfc8b2b4b6_prof);

    }

    public function getTemplateName()
    {
        return "SensioDistributionBundle::Configurator/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 11,  79 => 13,  76 => 12,  74 => 11,  71 => 10,  65 => 9,  53 => 7,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends "TwigBundle::layout.html.twig" %}*/
/* */
/* {% block head %}*/
/*     <link rel="stylesheet" href="{{ asset('bundles/sensiodistribution/webconfigurator/css/configurator.css') }}" />*/
/* {% endblock %}*/
/* */
/* {% block title 'Web Configurator Bundle' %}*/
/* */
/* {% block body %}*/
/*     <div class="block">*/
/*         {% block content %}{% endblock %}*/
/*     </div>*/
/*     <div class="version">Symfony Standard Edition v.{{ version }}</div>*/
/* {% endblock %}*/
/* */
